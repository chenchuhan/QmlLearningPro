#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <QObject>

class Customer : public QObject
{
    Q_OBJECT

public:
    Customer();

public slots:

private:

};

#endif // CUSTOMER_H
