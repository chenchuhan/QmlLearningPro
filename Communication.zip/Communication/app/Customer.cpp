#include "Customer.h"

Customer::Customer()
{

}
