<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="13"/>
        <source>Crazy Math</source>
        <translation>疯狂算术</translation>
    </message>
    <message>
        <location filename="../main.qml" line="78"/>
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../main.qml" line="156"/>
        <source>Correct</source>
        <translation>正确</translation>
    </message>
    <message>
        <location filename="../main.qml" line="161"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../main.qml" line="179"/>
        <source>Game Over!!!</source>
        <translation>游戏结束!!!</translation>
    </message>
    <message>
        <location filename="../main.qml" line="188"/>
        <source>Score:</source>
        <translation>得分:</translation>
    </message>
    <message>
        <location filename="../main.qml" line="204"/>
        <source>Current Best:</source>
        <translation>最高:</translation>
    </message>
    <message>
        <location filename="../main.qml" line="216"/>
        <source>Restart</source>
        <translation>重新开始</translation>
    </message>
</context>
<context>
    <name>InstrumentValue</name>
    <message>
        <location filename="../MathProblem/MathProblem.cpp" line="21"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../MathProblem/MathProblem.cpp" line="21"/>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../MathProblem/MathProblem.cpp" line="21"/>
        <source>Opacity</source>
        <translation type="unfinished">透明度</translation>
    </message>
    <message>
        <location filename="../MathProblem/MathProblem.cpp" line="21"/>
        <source>Icon</source>
        <translation type="unfinished">图标</translation>
    </message>
</context>
<context>
    <name>MathProblem</name>
    <message>
        <location filename="../MathProblem/MathProblem.cpp" line="50"/>
        <source>isTestEnglish</source>
        <translation>翻译测试</translation>
    </message>
</context>
<context>
    <name>FriendlyConversation</name>
    <message>
        <location filename="../MathProblem/MathProblem.cpp" line="50"/>
        <source>Hello</source>
        <translation>你好</translation>
    </message>
    <message>
        <location filename="../MathProblem/MathProblem.cpp" line="50"/>
        <source>Goodbye</source>
        <translation>再见</translation>
    </message>
</context>
</TS>
