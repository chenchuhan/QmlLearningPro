<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="13"/>
        <source>CrazyMath</source>
        <translation>疯狂算术</translation>
    </message>
    <message>
        <location filename="../main.qml" line="78"/>
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../main.qml" line="156"/>
        <source>Correct</source>
        <translation>正确</translation>
    </message>
    <message>
        <location filename="../main.qml" line="161"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../main.qml" line="179"/>
        <source>GameOver</source>
        <translation>游戏结束!</translation>
    </message>
    <message>
        <location filename="../main.qml" line="188"/>
        <source>Score:</source>
        <translation>得分:</translation>
    </message>
    <message>
        <location filename="../main.qml" line="204"/>
        <source>Current Best:</source>
        <translation>最高:</translation>
    </message>
    <message>
        <location filename="../main.qml" line="216"/>
        <source>Restart</source>
        <translation>重新开始</translation>
    </message>
</context>
</TS>
